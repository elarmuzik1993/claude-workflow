---
name: handoff
description: End the session so the next one, on any device, local or cloud, can resume from the repo alone. Use when the user says "hand off", "wrap up", "finish the session" or runs /workflow:handoff.
---

# Hand off

Works the same locally and in cloud sessions: nothing here depends on this machine. (Locally,
`/finalise` runs these steps and then syncs the Obsidian vault.)

The hand-off never needs a PR of its own. It rides in the work's PR, which it opens if there is
none yet, or, when there is no other work, goes straight to `main`. When it ends, **nothing is
left only on this machine**: every change is committed and pushed, each on its own branch and PR
(step 7 checks). Merging is `/finalise`'s job, on request.

1. **Verify.** Run `bash scripts/verify.sh`. If it fails, fix it or record the failure under
   *Known issues*. Never hand off a claim you didn't check.
2. **Pick where it goes.** Decide by what changed, not by the branch you are on: a cloud
   session always starts on a branch of its own, even when it does no work.
   `git fetch origin main`, then list what this branch changed since it left `main`:
   `git diff --name-only origin/main...HEAD` (committed; the same comparison the branch guard
   makes) and `git status --short` (not yet committed). Others' new commits on `main` don't count.
   - *Nothing but `.agents/STATE.md`* (a review, a redeploy recorded, a step done, a plan
     changed): the hand-off goes to `main`, from any branch, locally or in the cloud. It never
     goes on a branch of its own: that would need a PR of its own, and the branch guard refuses
     the push.
   - *Anything else:* the hand-off rides with the work on its `<type>/<work>` branch, so the
     branch's PR carries it. On `main`, move the work to a branch first
     (`git switch -c <type>/<work>`); in repos with the kit, the pre-push guard refuses anything
     but STATE.md on `main`.
3. **Rewrite `.agents/STATE.md`.** Replace it; don't append. History belongs in git. Create it
   if the repo has none yet.
   - *Now*: what the repo does and where it is deployed or rolled out, **as it will be once this
     branch merges** (on `main`: as it is). State only. How a command or script works belongs in
     its own file or `AGENTS.md`, never here.
   - *Next*: ordered, concrete steps. A fresh session must be able to start the first one cold.
     Steps that can only happen after the merge (redeploy, paste a block) go here.
   - *Decisions*: only those still shaping the work, each with its reason.
   - *Known issues*: failing checks, workarounds, anything a fresh session would trip on.

   Never write a branch or PR's status ("merged", "pushed", "PR #N open") or a list of merged
   PRs: git has those, and merging makes them wrong. Take facts from this session's command
   output and `git log`, not memory. Mark anything else `unverified`. Keep it within 60 lines; trim now,
   not at the next hand-off.

   Every PR rewrites STATE.md, so one merged first makes the next conflict. Then rebase on
   `main`, keep `main`'s STATE.md, and redo only this branch's changes to it.
4. **Update docs that changed,** in the same commit: `AGENTS.md` if rules, commands or layout
   changed; README if usage changed. Add a line to `AGENTS.md` only for a fact that is not
   already there; when one is, sharpen that line. Skip the rest and say you skipped them.
5. **Commit.** Stage everything this session changed, new files included (`git status --short`
   lists them; `git add -A` is right once you have read that list). Leave out secrets, `.env`
   files and machine-local files, and say so. Show `git diff --stat`, then commit with a message
   saying what changed and why. Follow the repo's commit rules in `AGENTS.md` (message style,
   commit identity). Unrelated changes may be separate commits; none stays uncommitted.
6. **Push,** to where step 2 picked. Running the hand-off is the request to push it.
   - *STATE.md only:* put the commit on top of `main` and push it there, from whatever branch
     you are on: `git rebase origin/main` (on `main`: `git pull --rebase origin main`), then
     `git push origin HEAD:main`. No branch is created, so a generated branch name doesn't
     matter and needs no rename. Never fall back to pushing a branch: the guard refuses it.
     If the remote refuses the push in the cloud, write the file to `main` through the GitHub
     connector instead (its create-or-update-file tool, with this commit's message), so the
     hand-off survives the container. If that fails too, or locally, stop and say so; in the
     cloud, also put the new STATE.md in full in the report.
   - *Work,* locally or in the cloud: push the branch and open or update its PR. The branch must
     be named `<type>/<work>`; rename a generated name first (`git branch -m <type>/<work>`),
     then `git push -u origin HEAD`. In the cloud (`CLAUDE_CODE_REMOTE=true`) this can't wait:
     the container is discarded and unpushed work is lost. Then the PR, with `gh` locally or
     the GitHub connector in the cloud:
     - *The branch has an open PR:* update its description to cover the whole branch now. Never
       open a second one.
     - *It has none:* open one against `main`. Title in the repo's commit style; the body says
       what changed and why, grouped by area, and quotes step 1's verify result. Follow the
       repo's PR template if it has one. Ready for review if verify passed; a **draft** if it
       failed, saying which check failed.
     - Never merge it, approve it or add AI attribution to it. With no GitHub access, the push
       still stands: say the PR wasn't opened and why.

   The hand-off pushes nothing but what step 7 finds unpushed.
7. **Leave nothing behind.** Check the whole repo, not only this branch:
   - `git status --short` is empty, and `git stash list` is empty or each stash is named in the
     report.
   - `git for-each-ref --format='%(refname:short) %(upstream:track)' refs/heads` shows no branch
     `[ahead N]` and none without an upstream; `git worktree list` shows no other worktree with
     uncommitted changes. (Branches that are only `gone` after a merge are fine.)
   - Any other branch with unpushed commits and a `<type>/<work>` name: push it and open or
     update its PR as step 6 does. Any with a generated or odd name, or a dirty worktree that
     is not this session's: don't rename, commit or push someone else's work on a guess. Name
     it in the report as *left behind*, with the command that would send it.
   - Compare what landed: `git rev-parse HEAD` equals the remote branch's tip
     (`git ls-remote origin <branch>`), or `main`'s for a STATE.md-only hand-off. A push that
     was refused or never made is reported as such, never as done.
8. **Report** two lists: *Updated* (every file touched) and *Skipped* (with the reason), then
   where each piece went: `main`, or each branch with its PR's link, and anything *left behind*.
